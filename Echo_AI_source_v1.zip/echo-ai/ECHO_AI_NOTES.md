# Echo AI adaptation notes

This folder is an adaptation of PocketClaw for the Echo AI school-project prototype.
The original MIT license and attribution are retained. Internal Dart package identifiers
and Android namespace remain unchanged to avoid breaking existing imports or native
plugin references.

## Current status
- App-facing label/title changed to Echo AI.
- Existing floating overlay and microphone/local-model paths are preserved.
- This is source code, not a compiled APK.
- The Android overlay permission and microphone permission must be granted explicitly.
- The local model needs to be downloaded while internet is available. Local inference
  may be slow or unsupported on lower-memory devices such as some entry-level phones.
- The accessibility service is optional and must be enabled explicitly in Android settings.
  Automatic extraction of quiz text from other apps is not guaranteed by this adaptation.
- Use for practice, revision, accessibility, or teacher-approved activities.

## Build
Install Flutter 3.41.x and the Android SDK, then run:
    flutter pub get
    flutter analyze
    flutter build apk --release

If analysis reports errors, fix them before installing the APK. Test on the target phone;
the included local model is large and performance is not guaranteed on the Infinix Hot 20i.
